#include <mpi.h>
#include <stdio.h>

int main(int argc, char* argv[]) {
    int rank, size, x;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Status status;

    if (rank == 0) {
        printf("Enter a base number in Master Process: ");
        scanf("%d", &x);  // Take the base number from the user

        // Send different numbers to each process
        for (int i = 1; i < size; i++) {
            int unique_value = x + i;  // Generate a unique number for each process
            MPI_Send(&unique_value, 1, MPI_INT, i, 1, MPI_COMM_WORLD);
            printf("Sent %d to process %d\n", unique_value, i);
        }
        printf("Reg_no is 220905128\n");
    } else {
        MPI_Recv(&x, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, &status);
        printf("Received %d in process %d\n", x, rank);
    }

    MPI_Finalize();
    return 0;
}
